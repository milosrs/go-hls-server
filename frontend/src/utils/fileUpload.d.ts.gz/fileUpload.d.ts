export declare const randomString: (length: number) => string;
export declare const createFileUpload: (hash: string) => string;
export declare const createFileChunks: () => Promise<Int8Array[]>;
